# Experimentelle ESP32 Art-Net / FastLED-Firmware

Diese neue Testfirmware ersetzt nicht automatisch sämtliche Funktionen der vorhandenen Firmware. Sie ist ausschließlich für einen identifizierten klassischen ESP32-Testcontroller vorgesehen. S3, C3, Web-Konfigurationseditor, OTA, ArtPoll, ArtSync, Quellen-Merge und beliebige dynamische Pinbelegung sind nicht implementiert.

## Reproduzierbarer Build (PowerShell)

Im Verzeichnis dieser README:

```powershell
python -m venv .venv
./.venv/Scripts/python.exe -m pip install platformio==6.1.18 ziglang==0.13.0
$env:PLATFORMIO_CORE_DIR = 'C:/Users/jbhtz/AppData/Local/CodexESP30/pio'
$env:PLATFORMIO_BUILD_DIR = 'C:/Users/jbhtz/AppData/Local/CodexESP30/build'
./.venv/Scripts/python.exe -m platformio run -j 2 -e esp32_testnode_mixed
New-Item -ItemType Directory -Force build | Out-Null
./.venv/Lib/site-packages/ziglang/zig.exe c++ -std=c++17 -nostdlib++ -O2 -Iinclude test/test_frame_assembler.cpp -o build/test_frame_assembler.exe
./build/test_frame_assembler.exe
```

Die R�ckwandprofile nutzen GPIOs 26,27,25,14,19,17 (GRB / WS2812B). Die Mixed-Profile verwenden WS an GPIO14 und APA102 DATA18/CLOCK19 mit Hardware-SPI4MHz; beide Treiber laufen gleichzeitig und synchronisieren vor dem n�chsten Frame:

| Profil | Pixel pro Port | Startuniversen |
|---|---|---|
| esp32_testnode_mixed (physischer Testaufbau) | WS256, APA512 | 0,2 |
| esp32_virtual_mixed1755 (virtueller Lasttest) | WS731, APA1024 | 0,5 |
| esp32_single | 203 | 120 |
| esp32_five | 203,738,880,810,352 | 120,122,127,133,139 |
| esp32_six | 203,738,880,810,352,1122 | 120,122,127,133,139,142 |

Der letzte 1122-Pixel-Port kann mit nominellem WS2812-Timing keine echten 30 vollständigen Lichtbilder pro Sekunde darstellen. Das Sechsportprofil ist ein Vergleichs-/Grenztest, kein 30-FPS-Versprechen. Pixeladressierung verwendet 170 RGB-Pixel pro Universum; bei 512 DMX-Slots werden die letzten zwei Slots ignoriert. Kürzere Pakete sind nur erlaubt, wenn sie alle tatsächlich benötigten RGB-Kanäle des betreffenden Universums enthalten.

## USB und Netzwerk

115200 Baud, zeilenbasierte Befehle:

- `status`: JSON-Telemetrie.
- `wifi SSID<TAB>PASSWORT`: Netzwerkzugang, Tabulator als Trenner; Zugangsdaten bleiben in eigenem NVS-Namespace und werden nicht ausgegeben. DHCP, gewünschte `.151` bei Bedarf als Routerreservierung. Bestehende NVS-Namespaces werden nicht gelöscht.
- `ip ADDRESS MASK GATEWAY`: statische IPv4-Konfiguration speichern/anwenden, beispielsweise `ip 10.0.0.151 255.0.0.0 10.0.0.1`.
- `arm`: Ausgabe freigeben; verwirft davor empfangene Mailboxdaten und unvollst�ndige Assemblerkandidaten. Erst hierbei werden LED-GPIOs initialisiert.
- `stop`: Ausgabe deaktivieren; letzter aktiver Output wird schwarz gesetzt.

HTTP: `GET /api/status`, `GET /api/config`, `POST /api/arm?enabled=true` bzw. `false`. Das Testinterface ist unverschlüsselt und ohne Login im lokalen Testnetz. Keine WLAN-Zugangsdaten in Git/Logs aufnehmen.

Nach Start und bei jedem neuen Arm müssen frische vollständige Frames eintreffen. Ohne vollständiges Frame wird nach einer Sekunde schwarz gesetzt. Feste Helligkeitsobergrenze16/255 (~6.3%), Zielsendetakt30FPS und Ausgabeobergrenze60FPS gegen Phasenaliasing. H�here theoretische Ausgangsrate ist kein Ersatz f�r Messung. Der Host sendet als fest zugelassener einzelner Sender10.0.0.125 ArtDmx an UDP6454; für eindeutige Messung pro Bild eine gemeinsame Nichtnull-Sequenz 1..255 verwenden. Sender mit unabhängigen Sequenzen pro Universum benötigen eine andere Assemblierungsstrategie.

## Messprotokoll

Vor und nach jedem 20-s-Lauf `/api/status` lesen. Getrennt berichten: gesendete Bilder, vollständige Empfangsbilder, `outputFrames`-Delta, unvollständige Frames, Mailboxüberschreibungen, RSSI, showCallUs. `outputFrames` zählt Treiberaufrufe, keine optische Verifikation. Kamera/Logic-Analyzer ergänzt den Nachweis tatsächlicher LED-Ausgabe. Artefakte/Status unter `docs/performance-program-20260912/esp/`.
